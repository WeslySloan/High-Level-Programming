

void main() {

	// This is my first line of code
	print("Hello World"); 			// this is another comment ....

	print("This is my first application");

	// Performing arithematic operation
	print(12 / 4);

	// Printing out boolean value
	print(false);
}
